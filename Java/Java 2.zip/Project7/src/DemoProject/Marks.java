package DemoProject;

import java.util.ArrayList;

public class Marks {

	public static void main(String[] args) {
		ArrayList<Markss> list=new ArrayList<>();//Object
		Markss m1=new Markss("java","9");
		Markss m2=new Markss("android","9");

		list.add(m1);
		list.add(m2);
		for( Markss m:list)
	{
		System.out.println(m.language+" "+m.mark);
		}
		}

		}
		class Markss
		{
		String language;
		String mark;
		public Markss(String language, String mark) {
		super();
		this.language = language;
		this.mark = mark;
		}
}
