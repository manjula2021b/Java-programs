package DemoProject;

import java.util.ArrayList;


public class addAllMethod {
	public static void main(String[] args) {
	ArrayList<String> letters = new ArrayList<>();
	letters.add("A");
	letters.add("B");
	letters.add("C");
	System.out.println(letters); // [A, B, C]
	ArrayList<String> words = new ArrayList<>();
	words.add("Apple");
	words.add("Ball");
	words.add("Cat");
	System.out.println(words); // [Apple, Ball, Cat]
	System.out.println (letters.addAll(words)); //true
	System.out.println(letters); // [A, B, C, Apple, Ball, Cat]
	}
	}


