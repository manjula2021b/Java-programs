package DemoProject;

import java.util.ArrayList;

import java.util.Scanner;

public class StudentFtriends {
	public static void main(String[] args) {
	// TODO Auto-generated method stub

	ArrayList <Stud> stu=new ArrayList<>();
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter the number of friends");
	int num=scan.nextInt();
	for(int i=0;i<num;i++)
	{
	System.out.println("Enter the name of friend");
	String name= scan.next();
	System.out.println("Enter the petname of friend");
	String petname= scan.next();
	System.out.println("Enter the mobile number of friends");
	int mobno=scan.nextInt();
	Stud s1=new Stud(name,petname,mobno);
	stu.add(s1);
	}
	for(Stud x:stu)
	{
	System.out.print("name is:"+x.name +"\tpetname is: "+x.petname+"\t"+"\tmobile number is: "+x.mobno+"\n\n");
	}
	}
	}
	class Stud
	{
	String name;
	String petname;
	int mobno;
	public Stud(String name, String petname, int mobno) {
	super();
	this.name = name;
	this.petname = petname;
	this.mobno = mobno;
	}
	}

