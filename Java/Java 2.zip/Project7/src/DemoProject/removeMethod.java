
package DemoProject;

import java.util.ArrayList;

public class removeMethod {

	public static void main(String[] args) {
		// create an ArrayList
		ArrayList<Integer> primeNumbers = new ArrayList<>();
		primeNumbers.add(2);
		primeNumbers.add(3);
		primeNumbers.add(5);
		System.out.println("ArrayList: " + primeNumbers);
		int removedElement = primeNumbers.remove(2);
		System.out.println("Removed Element: " + removedElement);
		}
		}