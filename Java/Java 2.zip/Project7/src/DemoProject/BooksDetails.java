package DemoProject;
import java.util.ArrayList;

public class BooksDetails {

		public static void main(String[] args) {
			ArrayList<Book> list=new ArrayList<>();//Object
			Book b1=new Book("Core Java","123","Albert",559);
			Book b2=new Book("C","456","Padma Reddy",350);

			list.add(b1);
			list.add(b2);
			for( Book b:list)
			{
		System.out.println(b.bookName+" "+b.id+" "+b.author+" "+b.price);
			}
			}



			}
			class Book
			{
			String bookName;
			String id,author;
			int price;
			public Book(String bookName, String id, String author, int price) {
				super();
				this.bookName = bookName;
				this.id = id;
				this.author = author;
				this.price = price;
			}
			
			
			}

