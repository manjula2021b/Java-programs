package DemoProject8;

import java.util.HashMap;
import java.util.Map;

public class StudentData {
	public static void main(String[] args) {
		HashMap<String,String> map=new HashMap<>();
		map.put("1","manjula");
		map.put("2","xyz");
		map.put("3","abc");
		map.put("4","ayz");

		for(Map.Entry<String,String> me:map.entrySet())
		{
		System.out.println(me.getKey() +" "+me.getValue());
		}
		}
		}
