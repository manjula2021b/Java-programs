package DemoProject8;

import java.util.HashMap;
import java.util.Map.Entry;

public class hashmapex {

	public static void main(String[] args) {
		HashMap<String,String> map=new HashMap<>();
		map.put("key1","abc");
		map.put("key2","xyz");
		map.put("key3","dhtilk");
		for(Entry<String, String> me:map.entrySet()) {
			System.out.println(me.getKey()+"and"+me.getValue());
			
		}
	}

}
