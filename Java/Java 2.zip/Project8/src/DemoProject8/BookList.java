package DemoProject8;

import java.util.HashMap;
import java.util.Map;

public class BookList
{
	public static void main(String[] args)
	{
			HashMap<String,Book> map=new HashMap<>();
			Book b1=new Book("456",237);
			Book b2=new Book("123",568);
			Book b3=new Book("789",679);
			map.put("Java",b1);
			map.put("html",b2);
			map.put("web",b3);

	for(Map.Entry<String,Book> me:map.entrySet())
	{
	System.out.println(me.getKey()+ " and "+me.getValue().id+" "+me.getValue().price);
	}
	}
}

class Book
{
	public static String salary;
	String id;
	int price;
	public Book(String id, int price)
	{
			super();
			this.id = id;
			this.price = price;
	}

}