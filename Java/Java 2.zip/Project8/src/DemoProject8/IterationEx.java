package DemoProject8;

import java.util.ArrayList;
import java.util.ListIterator;

public class IterationEx {

	public static void main(String[] args) {
		ArrayList<String> set=new ArrayList<>();
		set.add("red");
		set.add("red");
		set.add("red");
		set.add("black");
		set.add("blue");
		System.out.println(set);
		ListIterator i=set.listIterator();
		
		while(i.hasPrevious()) {
			System.out.println(i.hasPrevious());
		}
	}
}


class Studentt
{
	String name,pass;

	public Studentt(String name, String pass) {
		super();
		this.name = name;
		this.pass = pass;
	}
	
}

