package DemoProject8;

import java.util.ArrayList;
import java.util.Scanner;

public class Numbers {

	public static void main(String args[])
	{
	
		Scanner sc=new Scanner(System.in);
		ArrayList<Integer> list =new ArrayList<>();
		ArrayList<Integer> even =new ArrayList<>();
		ArrayList<Integer> odd =new ArrayList<>();
		ArrayList<Integer> prime =new ArrayList<>();
		
		
		int x;
		System.out.println("enter the array list");
		
		for(int i=1;i<=10;i++)
		{
		x=sc.nextInt();
		list.add(x);
		}
		System.out.println(list);
		
		
		int flag=0;
		for(int l:list) {
		if(l%2==0) {
		even.add(l);
		}
		else {
		odd.add(l);
		for(int i=2;i<=l/2;i++)
		{
		if(l%i==0) {
		flag=1;
		break;
		}
		}
		if(flag==0) {
		prime.add(l);
		}
		}
		}if(flag==0) {
		prime.add(1);
		}
		System.out.println("even numbers"+even);
		System.out.println("odd numbers"+odd);
		System.out.println("prime numbers"+prime);
		}
		}

			
