package DemoProject8;
import java.util.HashMap;


public class ClearMethodHashMap {
	public static void main(String[] args) {
		HashMap<Integer, String> hash_map = new HashMap<Integer, String>();

		// Mapping string values to int keys
		hash_map.put(10, "Hi");
		hash_map.put(15, "I am manjula");
		hash_map.put(20, "And");
		hash_map.put(25, "Welcomes");
		hash_map.put(30, "You");

		// Displaying the HashMap
		System.out.println("Initial Mappings are: " + hash_map);

		// Clearing the hash map using clear()
		hash_map.clear();

		// Displaying the final HashMap
		System.out.println("Finally the maps look like this: " + hash_map);
		}
		}