package DemoProject8;

import java.util.HashMap;
import java.util.Map;

public class language {
public static void main(String[] args) {
HashMap<String,String> map=new HashMap<>();
map.put("java","79");
map.put("php","60");
map.put("android","90");

for(Map.Entry<String,String> me:map.entrySet())
{
System.out.println(me.getKey()+ " and "+me.getValue());
}

}

}