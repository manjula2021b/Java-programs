package DemoProject8;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PrimeList
{
public static boolean isPrime(int x){
boolean itIs = true;
for (int i = 2; i < x; i++){
if(x%i == 0){
itIs = false;
}
}
return itIs;
}

public static void main(String[] args) {
int[] myArray={1,2,3,4,5,6,7,8,9,10} ;
int x = 20;
ArrayList<Integer>evenList = new ArrayList<Integer>();
ArrayList<Integer>oddList = new ArrayList<Integer>();
ArrayList<Integer> lista = new ArrayList<Integer>();

for (int i = 1; i<=x; i++)
{
lista.add(i);
}
System.out.println(lista);

for(int i=0;i<myArray.length;i++){
if (!isPrime(lista.get(i))){
lista.remove(lista.get(i));
}
}
System.out.println("prime numbers are\n"+lista);

for(int i=0;i<myArray.length;i++){
if(myArray[i]%2==0){
evenList.add(myArray[i]);
}else{
oddList.add(myArray[i]);
}
}
Collections.sort(evenList);
Collections.sort(oddList);
for(int even : evenList)
System.out.print("even number is"+even+",\n");

for(int odd : oddList)
System.out.print("odd number is"+odd+",\n");

}

}