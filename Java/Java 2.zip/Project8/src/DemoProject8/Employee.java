package DemoProject8;

import java.util.HashMap;
import java.util.Map;

public class Employee {

		public static void main(String[] args) {
		HashMap<String,EmployeeN> map=new HashMap<>();
		EmployeeN e1=new EmployeeN(50000,"237");
		EmployeeN e2=new EmployeeN(60000,"568");
		EmployeeN e3=new EmployeeN(80000,"679");
		map.put("manjula",e1);
		map.put("xyz",e2);
		map.put("abc",e3);

		for(Map.Entry<String,EmployeeN> me:map.entrySet())
		{
		System.out.println(me.getKey()+ " and "+me.getValue().salary+" "+me.getValue().id);
		}

		}

	}

	class EmployeeN
	{
		int salary;
		String id;
		public EmployeeN(int salary, String id) {
			super();
			this.salary = salary;
			this.id = id;
		}
		
		}
		

		
	
