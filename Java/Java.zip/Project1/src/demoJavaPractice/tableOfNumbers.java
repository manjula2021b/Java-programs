package demoJavaPractice;

public class tableOfNumbers {
	public static void main(String aa[])
	{
          int num=5;
          int i=1;
          while(i<=10)
          {
        	  System.out.print(i*num);
        	  i++;
          }
    
	}

}
