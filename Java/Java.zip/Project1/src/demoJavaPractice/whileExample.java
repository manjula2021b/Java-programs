package demoJavaPractice;

public class whileExample {
	public static void main(String aa[])
	{
		int a=8;
		while(a<=10)
		{

			 System.out.print("working!!");
			 a++;
		}
		int b=21;//example 2
	    while(b>=20)
	    {
	        System.out.print("working!!!\n");
	        b--;
	    }
	}
	

}
