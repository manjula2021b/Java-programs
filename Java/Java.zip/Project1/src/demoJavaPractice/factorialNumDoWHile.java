package demoJavaPractice;

public class factorialNumDoWHile {
	public static void main(String aa[])
	{
		int fact=1;
		int i=1,num=6;
		do {
			fact=fact*i;
			i++;
		}while(i<=num);
		System.out.print("Factorial of number"+num +"is"+fact );
		
	}
	

}
