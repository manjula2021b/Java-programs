package demoJavaPractice;

public class fifteen {
	public static void main(String aa[])
	{
		int i,fact=1;
		int number=4;
		for(i=1;i<=number;i++)
			fact=fact=fact*i;
		System.out.println("Factorial of number"+"is"+fact);
		
	}
	

}
