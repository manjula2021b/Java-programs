package demoJavaPractice;

public class eight {
	public static void main(String aa[])
	{
		
		int marks=589;
	      if(marks>=400 && marks<=600)
	        System.out.print("pass");
	      else
	          System.out.print("failed");
	    }
	}

