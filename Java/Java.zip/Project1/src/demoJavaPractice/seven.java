package demoJavaPractice;

public class seven {
	public static void main(String aa[]) 
	{
		 int a=15;

         if(a%3==0  && a%5==0 )
         {
            System.out.print("divisible by 5 and 3"); 
         }
         else {
             System.out.print(" not divisible by both 5 and 3"); 

         }


	}
	}


