package demoJavaPractice;

public class fourteen {
	public static void main(String aa[])
	{
       int totalCalls=250;
       if(totalCalls<=100)
    	   System.out.println("call is free and no bill");
       else if(totalCalls>=101 && totalCalls<=200)
       {
    	   totalCalls=totalCalls-100;
    	   System.out.println("Rs 1 per call and the bill is"+totalCalls*1);
       }
       else if(totalCalls>=201 && totalCalls<=300)
       {
    	   totalCalls=totalCalls-200;
       
    	   System.out.println("Rs 2 per call and the bill is"+totalCalls*2);
       }
       else 
       {
    	   totalCalls=totalCalls-300;
    	   System.out.println("Rs 3 per call and the bill is"+totalCalls*3);
       }
	}
}