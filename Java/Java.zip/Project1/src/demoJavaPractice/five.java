package demoJavaPractice;

public class five {
	public static void main(String aa[]) 
	{
		 char  var='o';
	        //vowels (a,e,i,o,u)
	        if(var=='a')
	        {
	            System.out.println("a is vowel");

	        }
	        else if(var=='e')
	        {
	            System.out.println("e is vowel");
	        }
	        else if(var=='i')
	        {
	            System.out.println("i is vowel");

	        }
	        else if(var=='o')
	        {
	            System.out.println("o is vowel");
	        }
	        else if(var=='u')
	        {
	            System.out.println("u is vowel");
	        }
	        else
	        {
	            System.out.println(var+" is not a vowel");

	        }
	    }
		
		
	}


