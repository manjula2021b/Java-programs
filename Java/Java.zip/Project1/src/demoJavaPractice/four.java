package demoJavaPractice;

public class four {
	public static void main(String aa[]) 
	{
	int age=22;
	
	if(age>=18)
	{
	System.out.println("user is valid for voting");
	}
	else
	{
		System.out.println("user is not valid for voting");
	}
}
}
