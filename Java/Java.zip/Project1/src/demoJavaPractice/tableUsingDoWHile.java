package demoJavaPractice;

public class tableUsingDoWHile {
	public static void main(String aa[])
	{
		int num=12;
		int i=1;
		do {
			System.out.print(num*i);
			i++;
			
	}
		while(i<=10);
	}
	

}
