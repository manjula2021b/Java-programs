package demoJavaPractice;

public class third {
	

	public static void main(String aa[]) {
		final double PI = 3.14;
		Object math;
	float principle=200, rate=6, time=3,avg;
	int a=10,b=20,c=4,d=25,e=30,sum,width=5,height=10,areaOfRectangle,areaOfCircle,areaOfSquare,s=5;
	float simpleInterest1= (principle*rate*time)/100;
	System.out.println("Simple interest is"+simpleInterest1);
	sum=a+b+c+d+e;
	avg=sum/5;
	System.out.println("Average of two numbers"+avg);
	areaOfRectangle=width*height;
	System.out.println("Area of rectangle"+areaOfRectangle);
	int raduis = 6;
	double areaOfCircle1= PI*raduis*raduis;
	System.out.println("Area of circle"+areaOfCircle1);
	areaOfSquare=s*s;
	System.out.println("Area of square"+areaOfSquare);
}
}