package demoJavaPractice;

public class sixteen {
	public static void main(String aa[])
	{
        int sum=0;
        for(int i=1;i<=100;i=i+2)
        	sum=sum+i;
        System.out.println("sum of even number 100 is"+sum);
	}

}
