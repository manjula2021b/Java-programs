package demoJavaPractice;

public class evenNUmWhile {
	public static void main(String aa[])
	{
		int sum=0,num=1;
		int count=0;
		while(count<=100)
		{
			if(num%2==0)
			{
				sum+=num;
				count++;
			}
			num++;
		}
		 System.out.print("Sum: "+sum);
	}
	

}
