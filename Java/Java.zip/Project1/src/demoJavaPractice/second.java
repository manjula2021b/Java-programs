package demoJavaPractice;

public class second {
	public static void main(String aa[])
	{
		
		System.out.println("hello");
	}

}
