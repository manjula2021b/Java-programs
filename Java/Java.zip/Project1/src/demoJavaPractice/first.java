package demoJavaPractice;

public class first {
	
		public static void main(String aa[])
		{
			String name="Manjula B", technology="java";
			int age=27;
			System.out.println("My Details:");
			System.out.println("My Name is:"+name);
			System.out.println("I am learning"+technology+ "technology");
			System.out.println("My Age is"+age);
			
		}

	}



