package demoJavaPractice;

public class thirteen {
	public static void main(String aa[])
	{
        int a=10,b=40,c=739,d=300;
        if(a>=b && a>=c && a>=d)
			System.out.println(a+" is the largest number");
		else if(b>=a && b>=c && b>=d)
			System.out.println(b+" is the largest number");
		else if(c>=a && c>=b && c>=d)
			System.out.println(c+" is the largest number");
		else if(d>=a && d>=b && d>=c)
		System.out.println(d+" is the largest number");
			

	}
	
	
	

}
