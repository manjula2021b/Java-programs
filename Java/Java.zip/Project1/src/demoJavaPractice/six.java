package demoJavaPractice;

public class six {
	public static void main(String aa[])
	{
		char  var='g';
		 
        if(var=='a' ||  var=='e' || var=='o' || var=='i' || var=='u' )  
            System.out.println(var+ " is vowel");
        else
            System.out.println(var+" is not a vowel");
	}
}
