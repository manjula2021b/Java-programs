package demoJavaPractice;

public class evenNumDoWhile {
	public static void main(String aa[])
	{
		int sum=0,i=0;
		do{
		sum=sum+i;
		i++;
		}while(i<=100);

		System.out.print(sum);

		}

		
	}
	


