package demoJavaPractice;

public class seventeen {
	public static void main(String aa[])
	{
		int number=50,i,sum=0, oddSum=0;
		for(i=1;i<=number;i++)
		{
			if(i%2!=0)
			{
				oddSum=oddSum+i;
			}
		}
	
	System.out.println("The odd sum of number 50 is"+oddSum);
	}

}
