package demoJavaPractice;

public class eighteen {
	public static void main(String aa[])
	{
		int b=9;
		for(int i=1;i<=1000;i++)
		
			if(b%9==0 && b%3==0)
			System.out.println("It is divisible");
		else
			System.out.println("It is not divisible");
		
	}
	
}
