package demoJavaPractice;

public class nine {

	public static void main(String aa[])
	{
		
		int n=20;
		if(n%2==0)
			System.out.println("number is even"+n);
		else
			System.out.println("number is odd");
	}
}
