package demoJavaPractice;

public class twele {
	public static void main(String aa[])
    {
    int marks=450; //total marks =500  
        if(marks>=400)
            System.out.print("A grade");
        else if(marks<400 && marks>=300)
            System.out.print("B grade");
        else if (marks<300 && marks>=250)
            System.out.print("c grade");
        else
            System.out.print("failed!!");
    }

}
