package demoJavaPractice;

public class MethodExample2 {

}
