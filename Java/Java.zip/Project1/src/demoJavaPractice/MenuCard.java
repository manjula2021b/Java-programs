package demoJavaPractice;

import java.util.Scanner;

public class MenuCard {
	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		int sum=0;
		char ch;
		do {
		System.out.println("bill order: \n 1.breakfast\n 2.lunch\n 3.dinner");
		int choice=sc.nextInt();
		if(choice==1) {
		System.out.println("breakfast: \n 1.idli\n 2.dosa\n 3.poori");
		int choice1=sc.nextInt();
		if(choice1==1) {
		sum+=30;
		System.out.println("idli of rs 30");
		}
		else if(choice1==2) {
		sum+=40;
		System.out.println("dosa of rs 40");
		}
		else if(choice1==3) {
		sum+=50;
		System.out.println("poori of rs 50");
		}

		}
		else if(choice==2) {
		System.out.println("lunch: \n 1.daal\n 2.naan\n 3.rooti");
		int choice2=sc.nextInt();
		if(choice2==1) {
		sum+=50;
		System.out.println("daal of rs 50");
		}
		else if(choice2==2) {
		sum+=40;
		System.out.println("naan of rs 40");
		}
		else if(choice2==3) {
		sum+=50;
		System.out.println("rooti of rs 50");
		}

		}
		else if(choice==3) {
		System.out.println("dinner: \n 1.pullav\n 2.pizza\n 3.puff");
		int choice3=sc.nextInt();
		if(choice3==1) {
		sum+=30;
		System.out.println("pallav of rs 30");
		}
		else if(choice3==2) {
		sum+=40;
		System.out.println("pizza of rs 40");
		}
		else if(choice3==3) {
		sum+=50;
		System.out.println("puff of rs 50");
		}

		}
		System.out.println("do yo want to repeat(y/n)");
		ch = sc.next().charAt(0);

		}while(ch=='y');
		int total=sum;
		System.out.println("total price"+total);
		sc.close();

	}

		}