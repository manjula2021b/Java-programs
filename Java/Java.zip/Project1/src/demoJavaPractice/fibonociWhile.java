package demoJavaPractice;

public class fibonociWhile {
	public static void main(String aa[])
	{
		int a, b, c, i = 1, n;
		n = 20;
		a = b = 1; System.out.print(a+" "+b);



		while(i<n) {
		c = a + b; System.out.print(" ");
		System.out.print(c);
		a = b;
		b = c;
		i++;
		}
	}

}
