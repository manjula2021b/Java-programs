package demoJavaPractice;

public class ten {
	public static void main(String aa[])
	{
		int n=42;
		if(n>0)
			System.out.println("Given number is positive"+n);
		else if(n<0)
			System.out.println("GIven number is negative"+n);
		else
			System.out.println("Given number is neither positive nor negative"+n);
	}

}
