package demoJavaPractice;

public class eleven {
	public static void main(String aa[])
	{
		int a=10,b=20,c=50;
		if(a>=b && a>=c)
			System.out.println(a+" is the largest number");
		else if(b>=a && b>=c)
			System.out.println(b+" is the largest number");
		else
			System.out.println(c+" is the largest number");
		
	}
	

}
