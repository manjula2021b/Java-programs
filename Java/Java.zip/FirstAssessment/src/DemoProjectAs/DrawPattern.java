package DemoProjectAs;
import java.util.Scanner;

public class DrawPattern {
	    public static void main(String[] args)
	{
	    	
	    		int rows = 4;
	    		for (int m=rows; m>=1; m--)
	    		{
	    		for (int n=1; n<=(m * 2) -1; n++)
	    		{
	    		System.out.print("*");
	    		}
	    		System.out.println();
	    		for (int p=rows; p>=m; p--)
	    		{
	    		System.out.print(" ");
	    		}
	    		}
	}
}
	

	    	
	    	
	    	
//	    Scanner sc = new Scanner(System.in);
//	    System.out.println("Enter the number of rows: ");
//	 
//	    int rows = 4;        
//	    for (int i= 0; i<= rows-1 ; i++)
//	    {
//	        for (int j=0; j<=i; j++)
//	        {
//	            System.out.print(" ");
//	        }
//	        for (int k=0; k<=rows-1-i; k++)
//	        {
//	            System.out.print("*" + " ");
//	        }
//	        System.out.println();
//	    }
//	    sc.close();
//	 
//	}
//	}

	
	
	
	
	
	

