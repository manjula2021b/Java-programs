package DemoProjectAs;

public class ReverseString {

	// Class of ReverseString
	    public static void main(String[] args)
	    {
	        String input = "HELLO";
	        StringBuilder input1 = new StringBuilder();
	        input1.append(input);
	        input1.reverse();
	        System.out.println(input1);
	    }
	}


