
package DemoProjectAs;

public class NumPattern {
	 public static void main(String args[]){ 
	int i, j;
   
	int number, n=5;   
	//loop for rows  
	for(i=0; i<n; i++)  
	{   
	number=1;   
	//loop for columns  
	for(j=0; j<=i; j++)  
	{  
	System.out.print(number+ " ");   
	//incrementing the value of number   
	number++;   
	}   
	//throws the cursor at the next line after printing each row  
	System.out.println();   
	}   
	}   
	}  

