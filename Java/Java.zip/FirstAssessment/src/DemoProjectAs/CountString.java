package DemoProjectAs;

public class CountString {

	  public static void main(String args[]) 
	  {
	      
	  String input = "Manjula";
	  char letterTOSearch = 'M';             // Character to search is 'a'.
	  
	  int count=0;
	  for(int i=0; i<input.length(); i++)
	  {
	      if(input.charAt(i) ==  letterTOSearch)
	      count++;
	  }
	  
	  System.out.println("The Character '"+ letterTOSearch+"' appears "+count+" times.");
	  }
	}


