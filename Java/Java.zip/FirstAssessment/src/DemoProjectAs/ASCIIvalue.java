package DemoProjectAs;

public class ASCIIvalue {


	public static void main(String[] args)   
	{  
	for(int i = 65; i <= 90; i++)  
	{  
	System.out.println(" The ASCII value of " + (char)i + "  =  " + i);  
	}  
	}  
	}  


