package DemoProjectAs;

import java.io.*;

public class CountVowels {
	
	  
	    public static void main(String[] args)
	        throws IOException
	    {
	        String str = "My Nephew is cute boy";
	
	            str = str.toLowerCase();
	        char[] chars = str.toCharArray();
	        int count = 0;
	        for (int i = 0; i < str.length(); i++)
	        {
	            if (str.charAt(i) == 'a' || str.charAt(i) == 'e'|| str.charAt(i) == 'i' || str.charAt(i) == 'o' || str.charAt(i) == 'u')
	            {
	                count++;
	            }
	        }
	  
	        
	        System.out.println("Total no of vowels in string are: " + count);
	    }
	}

















	
	
	
	
	
	
	



//
//		  public static void main(String[] args) {
//		    String line = "This website is aw3som3.";
//		    int vowels = 0, consonants = 0, digits = 0, spaces = 0;
//
//		    line = line.toLowerCase();
//		    for (int i = 0; i < line.length(); ++i) {
//		      char ch = line.charAt(i);
//
//		      // check if character is any of a, e, i, o, u
//		      if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
//		        ++vowels;
//		      }
//
//		      // check if character is in between a to z
//		      else if ((ch >= 'a' && ch <= 'z')) {
//		        ++consonants;
//		      }
//		      
//		      // check if character is in between 0 to 9
//		      else if (ch >= '0' && ch <= '9') {
//		        ++digits;
//		      }
//		      
//		      // check if character is a white space
//		      else if (ch == ' ') {
//		        ++spaces;
//		      }
//		    }
//
//		    System.out.println("Vowels: " + vowels);
//		    System.out.println("Consonants: " + consonants);
//	    System.out.println("Digits: " + digits);
//	    System.out.println("White spaces: " + spaces);
//		  }
//		}

