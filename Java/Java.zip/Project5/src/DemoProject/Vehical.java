package DemoProject;


interface IVehicle {
public double tuneUpCost();
public boolean canCarry(int numPassengers);
}



public class Vehical implements IVehicle
{
public double tuneUpCost()
{
int carrymillage=10000;
int noofyears=5;
double tuneup=carrymillage-noofyears;
return tuneup;

}
public boolean canCarry(int numPassengers)
{
if(numPassengers<=5)
{
return true;
}
else
{

}
return false;
}



public static void main(String[] args) {
// TODO Auto-generated method stub

Vehical v = new Vehical();
// System.out.println( v.canCarry(10));
System.out.println("tune cost is: "+v.tuneUpCost());
System.out.println("vehicle can hold given num of passengers: "+ v.canCarry(4));

}



}


