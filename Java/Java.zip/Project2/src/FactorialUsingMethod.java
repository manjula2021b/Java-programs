
public class FactorialUsingMethod {

}
