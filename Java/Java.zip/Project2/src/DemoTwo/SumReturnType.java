package DemoTwo;

public class SumReturnType {
	static int naturalNumberSum(int n)
	{
		int sum=0;
		for(int i=1;i<=n;i++)
			sum=sum+i;
		return sum;
	}
	public static void main(String aa[])
	{
		int n=100;
		System.out.println("Sum of numbers is"+ naturalNumberSum(n));
	}

}
