package DemoTwo;

public class AddMethod {
	 public int add(int x,int y)
	    {
	        return x+y;
	    }

	    public int add(int x,int y,int z)
	    {
	        return x+y+z;
	    }
	    public static void main(String aa[])
	    {
	    	AddMethod t=new AddMethod();
	         int a=t.add(3,8);  //11
	         int b=t.add(2,4,9);  //15
	         System.out.print( a+b );
	}
	}

}
