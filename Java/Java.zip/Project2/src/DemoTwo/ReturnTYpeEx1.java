package DemoTwo;

public class ReturnTYpeEx1 {
	 public  String getMessage(String name)
	    {
	        return "Welcome to our coding session "+name+" !!!";
	    }
	    public static void main(String aa[])
	    {
	    	ReturnTYpeEx1 t=new ReturnTYpeEx1();
	            System.out.print(t.getMessage("Sakshi"));

	}
	
}
