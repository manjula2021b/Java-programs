package DemoTwo;

public class PositiveNegativeReturnType {
	static String CheckPosNeg(int x)
	{
		if(x>0)
		return "Positive";
		else if(x<0)
			return "Negative";
		else
			return "zero";
	}
	public static void main(String aa[])
	{
      int firstNumber=912;
      System.out.println(firstNumber+"is"+CheckPosNeg(firstNumber));	
		
	}

}
