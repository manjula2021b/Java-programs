package DemoTwo;

public class FindArea {
	
		void area(float x)
		{
		System.out.println("The area of the square is "+Math.pow(x, 2));
		}
		void area(float x, float y)
		{
		System.out.println("The area of the rectangle is "+x*y);
		}
		void area(double x)
		{
		double z = 3.14 * x * x;
		System.out.println("The area of the circle is "+z);
		}
	public static void main(String[] args) {
			FindArea ob = new FindArea();
		ob.area(4);
		ob.area(34,56);
		ob.area(7);
		}
		}

