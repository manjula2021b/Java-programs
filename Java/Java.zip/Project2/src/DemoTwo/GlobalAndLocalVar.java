package DemoTwo;

public class GlobalAndLocalVar {
	static int i=90;
	
	static void changevariable()
	{
		i++;
		 System.out.println(i);
	}
	public static void main(String aa[])
	{
		GlobalAndLocalVar ob1=new GlobalAndLocalVar();
		GlobalAndLocalVar ob2=new GlobalAndLocalVar();
		GlobalAndLocalVar ob3=new GlobalAndLocalVar();
		ob1.changevariable();
		ob2.changevariable();
		ob3.changevariable();
		
	}
	

}

