package DemoTwo;

import java.util.Scanner;

public class MethodFactorial {
	private static final int PI = (int) 3.14;
	static int factorial(int n)
	{
		if(n==0)
			return 1;
		else
			return(n*factorial(n-1));
	}
	void area()
	{
		final double PI = 3.14;
		Object math;
	int a=10,b=20,c=4,d=25,e=30,sum,width=5,height=10,areaOfRectangle,areaOfCircle,areaOfSquare,s=5;
	areaOfRectangle=width*height;
	System.out.println("Area of rectangle"+areaOfRectangle);
	int raduis = 6;
	double areaOfCircle1= PI*raduis*raduis;
	System.out.println("Area of circle"+areaOfCircle1);
	areaOfSquare=s*s;
	System.out.println("Area of square"+areaOfSquare);
	
	
	}
 public void sum(float a, float b)
 {
	 System.out.println("sum is"+(a+b));
  
 }	
	
	
	
	
	public static void main(String aa[])
	{
		int i,fact=1;
		int number=5;
		fact=factorial(number);
		MethodFactorial ob= new MethodFactorial();
		System.out.print("factorial of"+number+"is"+fact);
		ob.area();
		ob.sum(16.7f, 29.8f);
		
    	
    	
    }
	}


