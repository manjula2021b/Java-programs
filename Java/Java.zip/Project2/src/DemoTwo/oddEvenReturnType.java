package DemoTwo;

import java.util.Scanner;

public class oddEvenReturnType {
	public static void main(String aa[])
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("enter the to check even or odd");
		int num=scan.nextInt();
		if(num%2==0)
			System.out.println(num+"is even");
		else
			System.out.println(num+"is odd");
	}
	
	static boolean find_oddeven(int num)
	{
		return(num%2==0);
	}

}
