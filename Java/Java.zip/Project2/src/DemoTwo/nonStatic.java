package DemoTwo;

public class nonStatic {
	int x=20;
//	non-static add
	
	static void changevariable()
	{
		
		x=89;
//		i++;
//		 System.out.println(i);
	}
	public static void main(String aa[])
	{
		nonStatic ob4=new nonStatic();
		nonStatic ob5=new nonStatic();
		nonStatic ob6=new nonStatic();
		System.out.println(ob4.x);
		System.out.println(ob5.x);
		System.out.println(ob6.x);
	}

}
