package Inheritence;

public class SingleInheritence {

	

}
