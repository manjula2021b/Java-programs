package DemoThree;

public class Students {
	
	String name;
	public Students(String s) {
	name=s;
	}
	public Students() {
	name="unknown";
	}



	public static void main(String[] args) {
	Students s=new Students("Manjula");
	Students a=new Students();
	System.out.println(s.name);
	System.out.println(a.name);



	}
	}
