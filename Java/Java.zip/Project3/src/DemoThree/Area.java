package DemoThree;

public class Area {
	Area(int r)
	{
		double area1=(3.13*r*r);
		System.out.println(area1);
	}
	
	Area(int l,int b)
	{
		int area2=l*b;
		System.out.println(area2);
	}
	Area(byte s)
	{
		int area3=s*s;
		System.out.println(area3);
	}
	 public static void main(String aa[])
	    {
		 Area a=new Area(10);
		 Area a1=new Area(10,20);
		 Area a2=new Area(2);
		 
	    }
}
