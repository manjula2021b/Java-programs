package DemoThree;

public class Student {
	String name,rollno;

void setName(String name)
{
    this.name=name;
}
 
void setRollno(String rollno)
{
    this.rollno=rollno;    
}
 
String getName()
{
    return name;
}
String getRollno()
{
    return rollno;
}
 
    public static void main(String aa[])
    {
         Student t1=new Student();
          t1.setName("Manjula");
          t1.setRollno("24");
          System.out.print(t1.getName()+"  "+t1.getRollno());
}
}
	