package DemoThree;

public class car {
	
		String brandname;
		String price;

		car(String brandname, String price)
		{
		this.brandname=brandname;
		this.price=price;
		}
		String displaydetails()
		{
		return price+" "+brandname;
		}



		public static void main(String[] args) {
		car c= new car("marute","80000");
		System.out.println(c.displaydetails());



		}



		}