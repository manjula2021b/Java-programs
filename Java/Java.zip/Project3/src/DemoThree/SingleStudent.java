package DemoThree;

import java.util.Scanner;

public class SingleStudent {
	int studentid;
	String studentname;
	String phone;
	Scanner s= new Scanner(System.in);
	public void ReadDetails()
	{
	System.out.println("enter the student details of id, name and phone num");
	int studentid=s.nextInt();
	String studentname=s.next();
	String phone=s.next();
	this.studentid=studentid;
	this.studentname=studentname;
	this.phone=phone;
	}
	public void displayDetails()
	{
	System.out.println(studentid+" "+studentname+" "+phone);
	}
}
	public class marks extends SingleStudent{
	int m1;
	int m2;
	int m3;
	Scanner s=new Scanner(System.in);
	}

	public void ReadMarks()
	{
	System.out.println("enter the marks m1,m2,m3: ");
	int m1=s.nextInt();
	int m2=s.nextInt();
	int m3=s.nextInt();

	this.m1=m1;
	this.m2=m2;
	this.m3=m3;
	public void display() {
	System.out.println(m1+" "+m2+" "=m3);
	}
	}
	public static void main(String args[]) {
	marks m=new marks;
	m.ReadMarks();
	m.display();
	m.displayDetails();
	}
	