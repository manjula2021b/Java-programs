package Inheritence;

import java.util.Scanner;

public class MultiLevel {

	Scanner s=new Scanner(System.in);
	 int studentId;
	 String studentname,phone;
	  
	 void readDetails()
	 {
	     System.out.println("Enter id");
	     studentId=s.nextInt();
	     System.out.println("Enter name");
	     studentname=s.next();
	     System.out.println("Enter phone");
	     phone=s.next();
	 }
	  
	 void displayDetails()
	 {
	     System.out.println("ID :"+studentId);
	     System.out.println("Name:"+studentname);
	     System.out.println("Phoneno :"+phone);
	 }
	 }
	  
	 class Marksheet extends Student
	 {
	     int m1,m2,m3;
	     int sum;
	  
	     void readMarks()
	     {
	         System.out.println("marks of Maths");
	         m1=s.nextInt();
	         System.out.println("marks of English");
	         m2=s.nextInt();
	         System.out.println("marks of Hindi");
	         m3=s.nextInt();
	     }

	     void displayMarks()
	     {
	         System.out.println("Marks ---\nMaths:"+m1);
	         System.out.println("English:"+m2);
	         System.out.println("hindi:"+m3);
	         int Total=m1+m2+m3;
	         System.out.println("enter totalmarks"+Total);
	         
	        
	     }
	 }
	 class Result extends  Marksheet
	 {
		 int totalmarks;
		 
		 
		 void calculateResult()
		 {
			 System.out.println("enter totalmarks");
			 totalmarks=s.nextInt();
				 
			 float percent=totalmarks*100/300;
			 System.out.println("Total percent"+percent);
		 }
		 void displayResult()
		 {	
			 int percentage;
			 System.out.println("enter percentage");
			 percentage= s.nextInt();
			 if(percentage>=90)
			 {
				 System.out.println("first class");
			 }
			 else if(percentage>=80)
			 {
				 System.out.println("second class");
			 }
			 else if(percentage>=70)
			 {
				 System.out.println("third class");
			 }
			 else
			 {
				 System.out.println("fail");
			 }
		 }
	 public static void main(String aa[])
	    {
	         Result r=new Result();
	         r.readDetails();
	         r.readMarks();
	         r.displayDetails();
	         r.displayMarks();
	         r.calculateResult();
	         r.displayResult();
	}    
	}
	 



