package DemoException;



import java.util.Scanner;
import java.util.InputMismatchException;



class StudentManagement extends Exception
{  
	StudentManagement(String error)
    {
		super(error);
	}
}

public class MyException {

	public static void main(String arg[])
    { 
		try
		{
			
			Scanner KB=new Scanner(System.in);
			
			
			System.out.print("Enter marks here : ");
			int h=KB.nextInt();
			
//			checking marks
			if(!(h>=0 && h>=200))
			{
				throw(new StudentManagement("Student failed"+h));
			}
			
			System.out.print("Entered marks are : " + h+"Student passed");			
			
		}
		catch(InputMismatchException e)
		{
			System.out.println("Invalid Input..Pls Input Integer Only..");
		}
		catch(StudentManagement e)
		{
			System.out.println("Error:"+e);
		}
	}
}






//package day5;
//
//
//
//public class ExceptionStudent {
//public static void main (String[] args)
//{
//int num=150;
//try
//{
//if(num<200)
//{
//throw new Markss("Failed Exception");
//}
//else {
//System.out.println("Student is pass");
//}
//}
//catch(Markss e)
//{
//System.out.println(e);
//}
//}
//
//
//
//}
//class Markss extends Exception
//{
//public Markss(String marks)
//{
//super(marks);
//}
//}

