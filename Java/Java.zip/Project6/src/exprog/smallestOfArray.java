package exprog;

public class smallestOfArray {

	public static void main(String[] args) {
		
		int[] arr = {25, 86, 41, 97, 22, 34};
	
		int smallest = Integer.MAX_VALUE;
		
		int index=0;
		while(index<arr.length) {
		
		if(smallest>arr[index]) {
		
		smallest=arr[index];
		}
		index++;
		}
		System.out.println("The smallest number is : "+ smallest);
		}
		

}
