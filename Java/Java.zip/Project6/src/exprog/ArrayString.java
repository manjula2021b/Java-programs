package exprog;

public class ArrayString {

	 public static void main(String aa[])
	    {
	    String vowels[]= {"a,A","e,E","i,I","o,O","u,U"};

	    for(int i=0;i<vowels.length;i++)
	    {
	        System.out.println(vowels[i]);
	    }

	    }
	

}
