package exprog;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
class myException extends Exception
{
	myException(String msg)
	{
		super(msg);
	}
}

public class q12Exception {

	public static void main(String args[])
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int n;
		try
		{
			System.out.println ("Enter a no.");
			n=Integer.parseInt(br.readLine());
			if(n%2==0)
			{
				System.out.println ("No. is even");
			}
			else
			{
				throw new myException("No. is not even");
			}
		}
		catch(myException me)
		{
			System.out.println (me);
		}
		catch(IOException ie)
		{
			System.out.println (ie);
		}
		
	}
}
