package DemoWeb.demotestingmockito;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.Mockito.*;
import junit.framework.TestCase;

public class TestCalculator  {
	
	Calculator c=null;
	CalculatorService service=mock(CalculatorService.class);

	
	
	
	@Before
	public void setUp()
	{
	c=new Calculator(service)	;
	}
	
	@Test
	public void testPerform()
	{
		when(service.add(3,3)).thenReturn(6);
		 assertEquals(6,c.perform(3, 3));
		
	}

}

