package threadDemoEx;

public class Demo extends Thread{
	public static void main(String [] args) {
		Demo d1=new Demo();//thread1
		Demo d2=new Demo();//thread2
		d1.start();
		d1.setName("t1");;
		d2.start();
		d2.setName("t2");
	}
	public void run()
	{
		String name=currentThread().getName();
		if(name.equals("t1"))
		{
			for(int i=1;i<=10;i++)
			{
				try {
					sleep(20000);//2000 milliseconds =2 sec
				}
				catch(Exception e)
				{
				}
				System.out.println(name+" : "+i);
				}
			}
		}
	}

