package threaDemoex;



public class Demo extends Employee implements Runnable {
	 
    public static void main(String []args){
       Demo d1=new Demo(); //Thread 1
       Thread t1=new Thread(d1);
         t1.start();
         t1.setName("t1");

    }

    public void run()
    {

        for(int i=1;i<=10;i++)
        {    
            try{
            Thread.sleep(2000);//2000 miliseconds= 2 sec

            }
            catch(Exception e)
            {

            }
              String manu = null;
			String name = manu;
			System.out.println(name+" : "+i);

    }


}
}
