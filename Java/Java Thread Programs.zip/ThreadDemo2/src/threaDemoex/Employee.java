package threaDemoex;

public class Employee {

}
