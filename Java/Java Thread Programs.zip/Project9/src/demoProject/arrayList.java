package demoProject;

import java.util.ArrayList;

public class arrayList {

	 public static void main(String aa[]) 
	    {
	        ArrayList<String> list=new ArrayList<>();

	        list.add("djch");

	        list.add("djch");

	        list.add("djch");

	        list.add("djch");

	        list.add("djch");
	        list.forEach(
	                (String n)->System.out.println(n));
	    }
	}