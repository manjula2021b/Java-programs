package demoProject;

public class listExample {

	  public static void main(String aa[]) 
	    {

	        cal c= (int x,int y) -> 
	        {
	            int z=x+y;
	            return z;
	        };


	        System.out.println(c.add(9,7));
	        }
	    }
	 
	 
	interface cal
	{
	    int add(int a,int b);
	}